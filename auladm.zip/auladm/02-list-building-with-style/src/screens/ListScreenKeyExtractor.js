import React from 'react'
// IMPORT FlatList
import { Text, StyleSheet, FlatList } from 'react-native'

const ListScreenKeyExtractor = () => {
    // CREATE AN ARRAY OF OBJECTS
    const friends = [
        { name: 'jose #1', idade:'idade: - 8' },
        { name: 'joao #2', idade:'idade: - 8' },
        { name: 'junior #3', idade:'idade: - 8' },
        { name: 'julia #4', idade:'idade: - 8' },
        { name: 'jeraldo #5', idade:'idade: - 8' },
        { name: 'joselina #6', idade:'idade: - 8' },
        { name: 'jefersson #7', idade:'idade: - 8' },
        { name: 'josué #8', idade:'idade: - 8' },
        { name: 'juliana #9' , idade:'idade: - 8'}
    ]

    return (
        <FlatList
            keyExtractor={(friend) => friend.name}
            data={friends} // THIS FlatList WILL INTERATE ALL ELEMENTS OF friends
            renderItem={(element) => {
                // element === { item: { name: 'Friend #1' }, index: 0 }
                return <Text style={styles.textStyle}>{element.item.name} {element.item.idade}</Text>
            }} />
    )
}

const styles = StyleSheet.create({
    textStyle: {
        borderWidth: '1px'
}
})

export default ListScreenKeyExtractor